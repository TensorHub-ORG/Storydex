"""引擎层类型定义"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Literal


@dataclass
class ToolCall:
    """工具调用"""
    id: str
    name: str
    arguments: dict[str, Any]
    raw_arguments: str | None = None
    parse_error: str | None = None
    source: str = "native"


@dataclass
class Message:
    """消息"""
    role: Literal["system", "user", "assistant", "tool"]
    content: str | None = None
    tool_calls: list[ToolCall] | None = None
    tool_call_id: str | None = None
    reasoning_content: str | None = None
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self, include_reasoning: bool = False) -> dict[str, Any]:
        """转换为API格式"""
        msg: dict[str, Any] = {"role": self.role}

        if self.content is not None:
            msg["content"] = self.content

        if self.tool_calls:
            native_tool_calls = [
                tc
                for tc in self.tool_calls
                if tc.source != "text_fallback" and not tc.id.startswith("text_call_")
            ]
        else:
            native_tool_calls = []

        if native_tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": json.dumps(tc.arguments),
                    },
                }
                for tc in native_tool_calls
            ]

        if self.tool_call_id:
            msg["tool_call_id"] = self.tool_call_id

        if include_reasoning and self.reasoning_content:
            msg["reasoning_content"] = self.reasoning_content

        return msg


@dataclass
class LLMUsage:
    """One terminal usage record for one Provider request.

    Reported token fields are only populated when ``source`` proves that the
    values came from a Provider response (or a future Provider query). Local
    estimates live in their own field and never impersonate reported usage.
    ``to_dict`` keeps the three legacy token aliases so older callers can read
    rich records without losing provenance.
    """

    source: Literal[
        "provider_response",
        "provider_query",
        "missing",
        "legacy_unknown",
    ]
    protocol: Literal["openai_chat", "anthropic_messages", "unknown"] = "unknown"
    request_id: str = ""
    requested_model: str = ""
    reported_model: str = ""
    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None
    cache_read_input_tokens: int | None = None
    cache_creation_input_tokens: int | None = None
    reasoning_tokens: int | None = None
    estimated_input_tokens: int | None = None
    estimator: str = ""
    total_derived: bool = False
    usage_snapshot_count: int = 0
    provider_details: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.source not in {
            "provider_response",
            "provider_query",
            "missing",
            "legacy_unknown",
        }:
            raise ValueError(f"unsupported usage source: {self.source}")
        if self.protocol not in {"openai_chat", "anthropic_messages", "unknown"}:
            raise ValueError(f"unsupported usage protocol: {self.protocol}")
        reported = (
            self.input_tokens,
            self.output_tokens,
            self.total_tokens,
            self.cache_read_input_tokens,
            self.cache_creation_input_tokens,
            self.reasoning_tokens,
        )
        if self.source == "missing" and any(value is not None for value in reported):
            raise ValueError("missing usage cannot contain Provider-reported token values")
        for value in (*reported, self.estimated_input_tokens):
            if value is not None and (
                isinstance(value, bool) or not isinstance(value, int) or value < 0
            ):
                raise ValueError("usage token values must be non-negative integers or None")
        if self.total_derived and self.total_tokens is None:
            raise ValueError("total_derived requires total_tokens")
        if (
            isinstance(self.usage_snapshot_count, bool)
            or not isinstance(self.usage_snapshot_count, int)
            or self.usage_snapshot_count < 0
        ):
            raise ValueError("usage_snapshot_count must be non-negative")

    def to_dict(self) -> dict[str, Any]:
        """Serialize the canonical record plus legacy three-field aliases."""
        return {
            "_type": "LLMUsage",
            "_version": 1,
            "source": self.source,
            "protocol": self.protocol,
            "request_id": self.request_id,
            "requested_model": self.requested_model,
            "reported_model": self.reported_model,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "cache_read_input_tokens": self.cache_read_input_tokens,
            "cache_creation_input_tokens": self.cache_creation_input_tokens,
            "reasoning_tokens": self.reasoning_tokens,
            "estimated_input_tokens": self.estimated_input_tokens,
            "estimator": self.estimator,
            "total_derived": self.total_derived,
            "usage_snapshot_count": self.usage_snapshot_count,
            "provider_details": dict(self.provider_details),
            # Compatibility aliases used by Coomi <= 1.1.5 and its callers.
            "prompt_tokens": self.input_tokens,
            "completion_tokens": self.output_tokens,
        }


@dataclass
class LLMResponse:
    """LLM响应"""
    content: str | None = None
    tool_calls: list[ToolCall] | None = None
    usage: dict[str, Any] | None = None
    reasoning_content: str | None = None


@dataclass
class TokenUsage:
    """Token 使用量追踪"""
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0


@dataclass
class Session:
    """会话"""
    id: str
    system_prompt: str = "You are Coomi Agent."
    messages: list[Message] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    token_usage: TokenUsage = field(default_factory=TokenUsage)
    current_model: str | None = None
    last_prompt_tokens: int = 0  # 最近一次 API 调用的 prompt_tokens（真实值）
    history_path: str | None = None
    active_skills: list[str] = field(default_factory=list)
    selected_mcps: list[str] = field(default_factory=list)

    def get_messages_for_api(self) -> list[dict[str, Any]]:
        """获取API格式的消息列表"""
        from .services.context.message_guard import prepare_messages_for_api

        return prepare_messages_for_api(self, repair=True)


# ============================================================
# Loop 模式类型
# ============================================================

class LoopStatus(str, Enum):
    """Loop 执行状态"""
    RUNNING = "running"
    PAUSED_ISSUE = "paused_issue"       # 遇到需要人工处理的问题
    PAUSED_NETWORK = "paused_network"   # 网络断开等待重连
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class Spec:
    """解析后的任务规格"""
    title: str
    goal: str
    steps: list[str]
    constraints: list[str]
    acceptance_criteria: list[str]
    resources: dict[str, str]           # 可用资源描述
    tools_allowed: list[str]            # 允许使用的工具
    tools_forbidden: list[str]          # 禁止使用的工具


@dataclass
class Checkpoint:
    """步骤检查点"""
    step_index: int
    step_summary: str                   # LLM 生成的步骤完成摘要
    files_changed: list[str]            # 已修改的文件路径列表
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class LoopSession:
    """Loop 模式会话"""
    loop_id: str
    spec: Spec
    status: LoopStatus = LoopStatus.RUNNING
    current_step: int = 0                # 当前执行到第几步（0-based）
    checkpoints: list[Checkpoint] = field(default_factory=list)
    retry_counts: dict[int, int] = field(default_factory=dict)  # step_index -> retry count
    started_at: datetime = field(default_factory=datetime.now)
    last_active_at: datetime = field(default_factory=datetime.now)
    loop_dir: Path | None = None         # .coomi/loops/{loop_id}/ 目录


class StepResult(str, Enum):
    """步骤执行结果"""
    SUCCESS = "success"
    RETRY = "retry"                      # 需要重试
    SKIP = "skip"                        # 跳过（写入 ISSUE.md 后）
    FAILED = "failed"                    # 最终失败

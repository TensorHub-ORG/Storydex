"""Normalize Provider usage without coupling callers to SDK response shapes."""

from __future__ import annotations

from dataclasses import replace
from typing import Any, Protocol, cast

from ...types import LLMUsage


_PROTOCOLS = {"openai_chat", "anthropic_messages", "unknown"}
_DETAIL_KEY_LIMIT = 100
_DETAIL_LIST_LIMIT = 100
_DETAIL_STRING_LIMIT = 1024
_SKIP = object()


class _UsageAdapter(Protocol):
    protocol: str

    def normalize(
        self,
        raw_usage: dict[str, Any],
        *,
        request_id: str,
        requested_model: str,
        reported_model: str,
    ) -> LLMUsage: ...


class _OpenAIChatUsageAdapter:
    protocol = "openai_chat"

    def normalize(
        self,
        raw_usage: dict[str, Any],
        *,
        request_id: str,
        requested_model: str,
        reported_model: str,
    ) -> LLMUsage:
        input_tokens = _token(raw_usage, "prompt_tokens", "input_tokens")
        output_tokens = _token(raw_usage, "completion_tokens", "output_tokens")
        total_tokens = _token(raw_usage, "total_tokens")
        cache_read = _first_not_none(
            _token(raw_usage, "cache_read_input_tokens", "cached_tokens"),
            _nested_token(raw_usage, "prompt_tokens_details", "cached_tokens"),
            _nested_token(raw_usage, "input_tokens_details", "cached_tokens"),
        )
        cache_creation = _token(raw_usage, "cache_creation_input_tokens")
        reasoning = _first_not_none(
            _token(raw_usage, "reasoning_tokens"),
            _nested_token(raw_usage, "completion_tokens_details", "reasoning_tokens"),
            _nested_token(raw_usage, "output_tokens_details", "reasoning_tokens"),
        )
        total_tokens, total_derived = _derive_total(
            total_tokens,
            input_tokens,
            output_tokens,
        )
        return LLMUsage(
            source="provider_response",
            protocol="openai_chat",
            request_id=request_id,
            requested_model=requested_model,
            reported_model=reported_model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            cache_read_input_tokens=cache_read,
            cache_creation_input_tokens=cache_creation,
            reasoning_tokens=reasoning,
            total_derived=total_derived,
            usage_snapshot_count=1,
            provider_details=_provider_details(
                raw_usage,
                {
                    "prompt_tokens",
                    "input_tokens",
                    "completion_tokens",
                    "output_tokens",
                    "total_tokens",
                    "cache_read_input_tokens",
                    "cached_tokens",
                    "cache_creation_input_tokens",
                    "reasoning_tokens",
                },
            ),
        )


class _AnthropicMessagesUsageAdapter:
    protocol = "anthropic_messages"

    def normalize(
        self,
        raw_usage: dict[str, Any],
        *,
        request_id: str,
        requested_model: str,
        reported_model: str,
    ) -> LLMUsage:
        input_tokens = _token(raw_usage, "input_tokens", "prompt_tokens")
        output_tokens = _token(raw_usage, "output_tokens", "completion_tokens")
        total_tokens = _token(raw_usage, "total_tokens")
        total_tokens, total_derived = _derive_total(
            total_tokens,
            input_tokens,
            output_tokens,
        )
        return LLMUsage(
            source="provider_response",
            protocol="anthropic_messages",
            request_id=request_id,
            requested_model=requested_model,
            reported_model=reported_model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            cache_read_input_tokens=_token(raw_usage, "cache_read_input_tokens"),
            cache_creation_input_tokens=_token(
                raw_usage,
                "cache_creation_input_tokens",
            ),
            reasoning_tokens=_token(raw_usage, "reasoning_tokens"),
            total_derived=total_derived,
            usage_snapshot_count=1,
            provider_details=_provider_details(
                raw_usage,
                {
                    "input_tokens",
                    "prompt_tokens",
                    "output_tokens",
                    "completion_tokens",
                    "total_tokens",
                    "cache_read_input_tokens",
                    "cache_creation_input_tokens",
                    "reasoning_tokens",
                },
            ),
        )


_ADAPTERS: dict[str, _UsageAdapter] = {
    "openai_chat": _OpenAIChatUsageAdapter(),
    "anthropic_messages": _AnthropicMessagesUsageAdapter(),
}


class UsageStreamAccumulator:
    """Fold any number of cumulative SDK snapshots into one terminal record."""

    def __init__(self, *, protocol: str, requested_model: str = "") -> None:
        self.protocol = protocol if protocol in _PROTOCOLS else "unknown"
        self.requested_model = str(requested_model or "")
        self._latest: LLMUsage | None = None
        self._snapshot_count = 0
        self._request_id = ""
        self._reported_model = ""

    def observe(self, response_or_chunk: Any) -> None:
        """Observe one response/chunk; no usage event is emitted here."""
        request_id, reported_model = _response_metadata(response_or_chunk)
        if request_id:
            self._request_id = request_id
        if reported_model:
            self._reported_model = reported_model

        raw_usage = _public_mapping(_field(response_or_chunk, "usage"))
        adapter = _ADAPTERS.get(self.protocol)
        if adapter is None or raw_usage is None:
            return
        self._snapshot_count += 1
        self._latest = adapter.normalize(
            raw_usage,
            request_id=self._request_id,
            requested_model=self.requested_model,
            reported_model=self._reported_model,
        )

    def finalize(
        self,
        *,
        estimated_input_tokens: int | None = None,
        estimator: str = "",
    ) -> LLMUsage:
        """Return exactly one Provider-reported or explicit-missing record."""
        estimate = _non_negative_int(estimated_input_tokens)
        if self._latest is not None:
            return replace(
                self._latest,
                request_id=self._request_id or self._latest.request_id,
                requested_model=self.requested_model,
                reported_model=self._reported_model or self._latest.reported_model,
                estimated_input_tokens=estimate,
                estimator=str(estimator or "") if estimate is not None else "",
                usage_snapshot_count=self._snapshot_count,
            )
        return LLMUsage(
            source="missing",
            protocol=cast(Any, self.protocol),
            request_id=self._request_id,
            requested_model=self.requested_model,
            reported_model=self._reported_model,
            estimated_input_tokens=estimate,
            estimator=str(estimator or "") if estimate is not None else "",
            usage_snapshot_count=0,
        )


def usage_from_response(
    response: Any,
    *,
    protocol: str,
    requested_model: str = "",
    estimated_input_tokens: int | None = None,
    estimator: str = "",
) -> LLMUsage:
    """Normalize one non-streaming Provider response through the protocol seam."""
    accumulator = UsageStreamAccumulator(
        protocol=protocol,
        requested_model=requested_model,
    )
    accumulator.observe(response)
    return accumulator.finalize(
        estimated_input_tokens=estimated_input_tokens,
        estimator=estimator,
    )


def _response_metadata(response: Any) -> tuple[str, str]:
    request_id = _first_text(
        _field(response, "id"),
        _field(response, "request_id"),
        _field(response, "_request_id"),
    )
    reported_model = _first_text(_field(response, "model"))
    return request_id, reported_model


def _field(value: Any, name: str) -> Any:
    if isinstance(value, dict):
        return value.get(name)
    return getattr(value, name, None)


def _public_mapping(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        return dict(value)
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            dumped = model_dump(exclude_none=True)
        except TypeError:
            dumped = model_dump()
        if isinstance(dumped, dict):
            return dumped
    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        dumped = to_dict()
        if isinstance(dumped, dict):
            return dumped
    namespace = getattr(value, "__dict__", None)
    return dict(namespace) if isinstance(namespace, dict) else None


def _token(value: dict[str, Any], *names: str) -> int | None:
    for name in names:
        if name in value:
            parsed = _non_negative_int(value.get(name))
            if parsed is not None:
                return parsed
    return None


def _nested_token(value: dict[str, Any], parent: str, child: str) -> int | None:
    nested = _public_mapping(value.get(parent))
    return _token(nested, child) if nested is not None else None


def _non_negative_int(value: Any) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        parsed = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return parsed if parsed >= 0 else None


def _derive_total(
    total: int | None,
    input_tokens: int | None,
    output_tokens: int | None,
) -> tuple[int | None, bool]:
    if total is not None:
        return total, False
    if input_tokens is not None and output_tokens is not None:
        return input_tokens + output_tokens, True
    return None, False


def _first_not_none(*values: int | None) -> int | None:
    return next((value for value in values if value is not None), None)


def _first_text(*values: Any) -> str:
    for value in values:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def _provider_details(
    raw_usage: dict[str, Any],
    consumed_keys: set[str],
) -> dict[str, Any]:
    details: dict[str, Any] = {}
    for raw_key, raw_value in list(raw_usage.items())[:_DETAIL_KEY_LIMIT]:
        key = str(raw_key)
        if key in consumed_keys or _sensitive_detail_key(key):
            continue
        safe_value = _safe_json_value(raw_value, depth=0)
        if safe_value is not _SKIP:
            details[key] = safe_value
    return details


def _sensitive_detail_key(key: str) -> bool:
    normalized = str(key or "").strip().lower().replace("-", "_")
    if normalized in {
        "authorization",
        "body",
        "content",
        "cookie",
        "headers",
        "message",
        "messages",
        "output",
        "password",
        "prompt",
        "request",
        "response",
        "secret",
        "token",
    }:
        return True
    return any(
        fragment in normalized
        for fragment in ("api_key", "authorization", "cookie", "password", "secret")
    )


def _safe_json_value(value: Any, *, depth: int) -> Any:
    if depth > 5:
        return _SKIP
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:_DETAIL_STRING_LIMIT]
    mapping = _public_mapping(value)
    if mapping is not None:
        result: dict[str, Any] = {}
        for raw_key, raw_item in list(mapping.items())[:_DETAIL_KEY_LIMIT]:
            key = str(raw_key)
            if _sensitive_detail_key(key):
                continue
            item = _safe_json_value(raw_item, depth=depth + 1)
            if item is not _SKIP:
                result[key] = item
        return result
    if isinstance(value, (list, tuple)):
        result = []
        for raw_item in list(value)[:_DETAIL_LIST_LIMIT]:
            item = _safe_json_value(raw_item, depth=depth + 1)
            if item is not _SKIP:
                result.append(item)
        return result
    return _SKIP
